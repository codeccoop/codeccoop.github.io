document.addEventListener("DOMContentLoaded", function () {
  if (isMobile()) {
    document.documentElement.classList.add("is-mobile");
    document.body.classList.add("is-mobile");
  }
});
